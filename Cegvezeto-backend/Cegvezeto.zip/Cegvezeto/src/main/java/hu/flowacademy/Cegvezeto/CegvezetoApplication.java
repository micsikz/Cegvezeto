package hu.flowacademy.Cegvezeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CegvezetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CegvezetoApplication.class, args);
	}

}
